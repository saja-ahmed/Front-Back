// let arr = ['saja', 'yahia', 'marwo'];
// arr.shift();
// console.log(arr);










// let fruits = ["apple", "pear", "orange"];
// fruits.push("peache");
// let shppingCart = fruits;
// shppingCart.push("banana");
// alert (fruits.length)