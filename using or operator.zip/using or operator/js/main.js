function sayHello(username, age) {
    age = age || "unknow"
    return `hello ${username} your age is ${age}`
}
console.log (sayHello("saja", ))
